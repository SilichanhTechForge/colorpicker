namespace Project4

open WebSharper
open WebSharper.JavaScript
open WebSharper.UI
open WebSharper.UI.Client
open WebSharper.UI.Templating
open WebSharper.UI.Html


[<JavaScript>]
module Client =

    // Define a function to handle color selection
    let handleColorSelection (color: string) =
        let (container: obj) = Doc.RunById "color-container" :?> Div
        container.style [ CSS.BackgroundColor (CSS.Color color) ]

    // Create a color picker
    let colorPicker =
        Input [Attr.Type "color"; OnChange (fun e -> handleColorSelection e.Value)]

    // Main function to render the UI
    let main () =
        Div [
            H1 [Text "Choose a Color"]
            colorPicker
            Div [Attr.Id "color-container"]
        ]

    // Start the application
    [<SPAEntryPoint>]
    let Main () =
        main()
        |> Doc.RunById "main"
